import StatisticLine from './StatisticLine';

const Statistics = ({ good, neutral, bad }) => {
  // Total feedback count
  const total = good + neutral + bad;

  // Average score calculation (good: 1, neutral: 0, bad: -1)
  const average = total > 0 ? (good * 1 + neutral * 0 + bad * -1) / total : 0;

  // Percentage of positive feedback
  const positivePercentage = total > 0 ? (good / total) * 100 : 0;

  return (
    <div>
      <h2>Feedback Statistics</h2>
      <StatisticLine text="Good" value={good} />
      <StatisticLine text="Neutral" value={neutral} />
      <StatisticLine text="Bad" value={bad} />
      <StatisticLine text="Average score" value={average.toFixed(2)} />
      <StatisticLine text="Positive feedback" value={positivePercentage.toFixed(2) + '%'} />
    </div>
  );
};

export default Statistics;
