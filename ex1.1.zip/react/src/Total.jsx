const Total = ({ totalExercises }) => {
  return <p>Number of exercises {totalExercises}</p>;
};

export default Total
