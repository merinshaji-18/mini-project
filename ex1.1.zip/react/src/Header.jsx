const Header = ({ course }) => {
  return <h1>{course}</h1>;
};

export default Header
