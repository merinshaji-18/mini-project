const Statistics = ({ good, neutral, bad }) => {
  // Total feedback count
  const total = good + neutral + bad;

  // Average score calculation (good: 1, neutral: 0, bad: -1)
  const average = total > 0 ? (good * 1 + neutral * 0 + bad * -1) / total : 0;

  // Percentage of positive feedback
  const positivePercentage = total > 0 ? (good / total) * 100 : 0;

  return (
    <div>
      <h2>Feedback Statistics</h2>
      <p>Total feedback: {total}</p>
      <p>Good: {good}</p>
      <p>Neutral: {neutral}</p>
      <p>Bad: {bad}</p>
      <p>Average score: {average.toFixed(2)}</p>
      <p>Positive feedback: {positivePercentage.toFixed(2)}%</p>
    </div>
  );
};

export default Statistics;
